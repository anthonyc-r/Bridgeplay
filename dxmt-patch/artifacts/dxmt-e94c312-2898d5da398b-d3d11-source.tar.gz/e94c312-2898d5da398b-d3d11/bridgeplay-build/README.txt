DXMT source: e94c312f5c054263acf261cfa109edf13e757587
LLVM source: https://github.com/llvm/llvm-project at 8dfdcc7b7bf66834a761bd8de445840ef68e4d1a
Wine SDK source: https://github.com/wine-mirror/wine at 2df1ee28039cf84776eb1421ed90bd154cebb65f
Patch sha256: 2898d5da398b4b62197ddc60a82f37376482651de87df8bbe8da3e0d5c93d927
D3D11-only build: 1

The parent directory contains the exact patched DXMT sources used for this build.
The scripts directory contains the dependency pins and build/package recipe.
The patch is already applied to the parent sources; use it only with a clean checkout.
