/*
 * Copyright 2026 Feifan He for CodeWeavers
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#include "dxmt_context.hpp"
#include "Metal.hpp"
#include "dxmt_command_queue.hpp"
#include "dxmt_deptrack.hpp"
#include "dxmt_format.hpp"
#include "dxmt_occlusion_query.hpp"
#include "dxmt_presenter.hpp"
#include "wsi_platform.hpp"
#include <cstdint>
#include <cfloat>

namespace dxmt {

ArgumentEncodingContext::ArgumentEncodingContext(CommandQueue &queue, WMT::Device device, InternalCommandLibrary &lib) :
    device_(device),
    lib(lib),
    emulated_cmd(device, lib, *this),
    clear_rt_cmd(device, *this),
    blit_depth_stencil_cmd(device, lib, *this),
    clear_uav_cmd(device, *this),
    mv_scale_cmd(device, lib, *this),
    tile_barrier_cmd(device, lib, *this),
    timestamp_state_(device),
    queue_(queue) {
  dummy_sampler_info_.support_argument_buffers = true;
  dummy_sampler_info_.border_color = WMTSamplerBorderColorTransparentBlack;
  dummy_sampler_info_.compare_function = WMTCompareFunctionNever;
  dummy_sampler_info_.normalized_coords = true;
  dummy_sampler_info_.r_address_mode = WMTSamplerAddressModeClampToEdge;
  dummy_sampler_info_.s_address_mode = WMTSamplerAddressModeClampToEdge;
  dummy_sampler_info_.t_address_mode = WMTSamplerAddressModeClampToEdge;
  dummy_sampler_info_.min_filter = WMTSamplerMinMagFilterNearest;
  dummy_sampler_info_.mag_filter = WMTSamplerMinMagFilterNearest;
  dummy_sampler_info_.mip_filter = WMTSamplerMipFilterNotMipmapped;
  dummy_sampler_info_.lod_min_clamp = 0.0f;
  dummy_sampler_info_.lod_max_clamp = FLT_MAX;
  dummy_sampler_info_.max_anisotroy = 1;
  dummy_sampler_info_.lod_average = false;
  dummy_sampler_ = device.newSamplerState(dummy_sampler_info_);
  dummy_cbuffer_host_ = wsi::aligned_malloc(65536, DXMT_PAGE_SIZE);
  dummy_cbuffer_info_.length = 65536;
  dummy_cbuffer_info_.memory.set(dummy_cbuffer_host_);
  dummy_cbuffer_info_.options = WMTResourceOptionCPUCacheModeWriteCombined | WMTResourceStorageModeShared |
                                WMTResourceHazardTrackingModeUntracked;
  dummy_cbuffer_ = device.newBuffer(dummy_cbuffer_info_);
  std::memset(dummy_cbuffer_info_.memory.get(), 0, 65536);
  cpu_buffer_chunks_.emplace_back();
  barrier_event_ = device_.newEvent();
  for (unsigned i = 0; i < kParityLane; i++) {
    fence_pool_[i] = device.newFence();
  }
};

ArgumentEncodingContext::~ArgumentEncodingContext() {
  wsi::aligned_free(dummy_cbuffer_host_);
};

template void ArgumentEncodingContext::encodeVertexBuffers<PipelineKind::Ordinary>(uint32_t slot_mask, uint64_t argument_buffer_offset);
template void ArgumentEncodingContext::encodeVertexBuffers<PipelineKind::Tessellation>(uint32_t slot_mask, uint64_t argument_buffer_offset);
template void ArgumentEncodingContext::encodeVertexBuffers<PipelineKind::Geometry>(uint32_t slot_mask, uint64_t argument_buffer_offset);

template <PipelineKind kind>
void
ArgumentEncodingContext::encodeVertexBuffers(uint32_t slot_mask, uint64_t offset) {
  struct VERTEX_BUFFER_ENTRY {
    uint64_t buffer_handle;
    uint32_t stride;
    uint32_t length;
  };
  uint32_t max_slot = 32 - __builtin_clz(slot_mask);

  VERTEX_BUFFER_ENTRY *entries = getMappedArgumentBuffer<VERTEX_BUFFER_ENTRY>(offset);

  for (unsigned slot = 0, index = 0; slot < max_slot; slot++) {
    if (!(slot_mask & (1 << slot)))
      continue;
    auto &state = vbuf_[slot];
    auto &buffer = state.buffer;
    if (!buffer.ptr()) {
      entries[index].buffer_handle = 0;
      entries[index].stride = 0;
      entries[index++].length = 0;
      continue;
    }
    auto valid_length = buffer->length() > state.offset ? buffer->length() - state.offset : 0;
    auto [buffer_alloc, buffer_offset] =
        access<PipelineStage::Vertex>(buffer, state.offset, valid_length, ResourceAccess::Read);
    entries[index].buffer_handle = buffer_alloc->gpuAddress() + buffer_offset + state.offset;
    entries[index].stride = state.stride;
    entries[index++].length = valid_length;
    // FIXME: did we intended to use the whole buffer?
    makeResident<PipelineStage::Vertex, kind>(buffer.ptr());
  };
  {
    auto &cmd = encodeRenderCommand<wmtcmd_render_setbufferoffset>();
    cmd.offset = getFinalArgumentBufferOffset(offset);
    cmd.index = SM50_BINDING_INDEX_VERTEX_BUFFER;
    if constexpr (kind == PipelineKind::Geometry || kind == PipelineKind::Tessellation)
      cmd.type = WMTRenderCommandSetObjectBufferOffset;
    else
      cmd.type = WMTRenderCommandSetVertexBufferOffset;
  }
}
struct SO_BUFFER_ENTRY {
  uint64_t buffer_handle;
  uint64_t counter_handle;
};

template <>
void
ArgumentEncodingContext::encodeStreamOutputBuffers<PipelineKind::Ordinary>(uint64_t offset) {

  SO_BUFFER_ENTRY *entries = getMappedArgumentBuffer<SO_BUFFER_ENTRY>(offset);

  for (unsigned slot = 0; slot < kStreamOutputSlots; slot++) {
    auto &state = so_[slot];
    auto &buffer = state.buffer;
    if (!buffer.ptr()) {
      entries[slot].buffer_handle = 0;
      entries[slot].counter_handle = 0;
      continue;
    }
    auto [buffer_alloc, buffer_offset] = access<PipelineStage::Vertex>(buffer, state.offset, 0, ResourceAccess::Write);
    entries[slot].buffer_handle = buffer_alloc->gpuAddress() + buffer_offset + state.offset;
    entries[slot].counter_handle = 0; // TODO(stream-output): counter & buffer_filled_size
    makeResident<PipelineStage::Vertex, PipelineKind::Ordinary>(buffer.ptr(), false, true);
  };
  {
    auto &cmd = encodeRenderCommand<wmtcmd_render_setbufferoffset>();
    cmd.offset = getFinalArgumentBufferOffset(offset);
    cmd.index = SM50_BINDING_INDEX_STREAM_OUTPUT0;
    cmd.type = WMTRenderCommandSetVertexBufferOffset;
  }

  currentRenderEncoder()->use_emulated_so = 1;
}

template <>
void
ArgumentEncodingContext::encodeStreamOutputBuffers<PipelineKind::Tessellation>(uint64_t offset) {
  ERR("unimplemented stream output from tessellation pipeline");
}
template <>
void
ArgumentEncodingContext::encodeStreamOutputBuffers<PipelineKind::Geometry>(uint64_t offset) {
  ERR("unimplemented stream output from geometry pipeline");
}

template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Vertex, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Pixel, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Vertex, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Pixel, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Hull, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Domain, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Compute, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Vertex, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Geometry, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeConstantBuffers<PipelineStage::Pixel, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *constant_buffers,
    uint64_t argument_buffer_offset
);

template <PipelineStage stage, PipelineKind kind>
void
ArgumentEncodingContext::encodeConstantBuffers(const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT * constant_buffers, uint64_t offset) {
  uint64_t *encoded_buffer = getMappedArgumentBuffer<uint64_t, stage == PipelineStage::Compute>(offset);

  for (unsigned i = 0; i < reflection->NumConstantBuffers; i++) {
    auto &arg = constant_buffers[i];
    auto slot = 14 * unsigned(stage) + arg.SM50BindingSlot;
    switch (arg.Type) {
    case SM50BindingType::ConstantBuffer: {
      auto &cbuf = cbuf_[slot];
      if (!cbuf.buffer.ptr()) {
        encoded_buffer[arg.StructurePtrOffset] = dummy_cbuffer_info_.gpu_address;
        makeResident<stage, kind>(dummy_cbuffer_, GetResidencyMask<kind>(stage, true, false));
        continue;
      }
      auto argbuf = cbuf.buffer;
      auto valid_length = argbuf->length() > cbuf.offset ? argbuf->length() - cbuf.offset : 0;
      auto [argbuf_alloc, argbuf_offset] = access<stage>(argbuf, cbuf.offset, valid_length, ResourceAccess::Read);
      encoded_buffer[arg.StructurePtrOffset] = argbuf_alloc->gpuAddress() + argbuf_offset + cbuf.offset;
      makeResident<stage, kind>(argbuf.ptr());
      break;
    }
    default:
      DXMT_UNREACHABLE
    }
  }

  if constexpr (stage == PipelineStage::Compute) {
    auto &cmd = encodeComputeCommand<wmtcmd_compute_setbufferoffset>();
    cmd.type = WMTComputeCommandSetBufferOffset;
    cmd.offset = getFinalArgumentBufferOffset<true>(offset);
    cmd.index = SM50_BINDING_INDEX_CONSTANT_BUFFER;
  } else {
    auto &cmd = encodeRenderCommand<wmtcmd_render_setbufferoffset>();
    cmd.offset = getFinalArgumentBufferOffset(offset);
    cmd.index = SM50_BINDING_INDEX_CONSTANT_BUFFER;
    if constexpr (stage == PipelineStage::Vertex) {
      if constexpr (kind == PipelineKind::Geometry)
        cmd.type = WMTRenderCommandSetObjectBufferOffset;
      else if constexpr (kind == PipelineKind::Tessellation) {
        cmd.type = WMTRenderCommandSetObjectBufferOffset;
        cmd.index = SM50_BINDING_INDEX_CONSTANT_BUFFER2;
      } else
        cmd.type = WMTRenderCommandSetVertexBufferOffset;
    } else if constexpr (stage == PipelineStage::Pixel) {
      cmd.type = WMTRenderCommandSetFragmentBufferOffset;
    } else if constexpr (stage == PipelineStage::Hull) {
      cmd.type = WMTRenderCommandSetObjectBufferOffset;
    } else if constexpr (stage == PipelineStage::Domain) {
      cmd.type = WMTRenderCommandSetMeshBufferOffset;
    } else if constexpr (stage == PipelineStage::Geometry) {
      cmd.type = WMTRenderCommandSetMeshBufferOffset;
    } else {
      assert(0 && "Not implemented or unreachable");
    }
  }
};

template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Vertex, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Pixel, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Vertex, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Pixel, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Hull, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Domain, PipelineKind::Tessellation>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Compute, PipelineKind::Ordinary>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Vertex, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Geometry, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);
template void ArgumentEncodingContext::encodeShaderResources<PipelineStage::Pixel, PipelineKind::Geometry>(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t argument_buffer_offset
);

inline uint64_t
TextureMetadata(uint32_t array_length, float min_lod) {
  return ((uint64_t)array_length << 32) | (uint64_t)std::bit_cast<uint32_t>(min_lod);
}

template <PipelineStage stage, PipelineKind kind>
void
ArgumentEncodingContext::encodeShaderResources(
    const MTL_SHADER_REFLECTION *reflection, const MTL_SM50_SHADER_ARGUMENT *arguments, uint64_t offset
) {
  auto BindingCount = reflection->NumArguments;
  uint64_t *encoded_buffer = getMappedArgumentBuffer<uint64_t, stage == PipelineStage::Compute>(offset);

  auto &UAVBindingSet = stage == PipelineStage::Compute ? cs_uav_ : om_uav_;

  for (unsigned i = 0; i < BindingCount; i++) {
    auto &arg = arguments[i];
    switch (arg.Type) {
    case SM50BindingType::ConstantBuffer: {
      DXMT_UNREACHABLE
    }
    case SM50BindingType::Sampler: {
      auto slot = 16 * unsigned(stage) + arg.SM50BindingSlot;
      auto &sampler = sampler_[slot].sampler;
      if (!sampler) {
        encoded_buffer[arg.StructurePtrOffset] = dummy_sampler_info_.gpu_resource_id;
        encoded_buffer[arg.StructurePtrOffset + 1] = dummy_sampler_info_.gpu_resource_id;
        encoded_buffer[arg.StructurePtrOffset + 2] = (uint64_t)std::bit_cast<uint32_t>(0.0f);
        break;
      }
      encoded_buffer[arg.StructurePtrOffset] = sampler->sampler_state_handle;
      encoded_buffer[arg.StructurePtrOffset + 1] = sampler->sampler_state_cube_handle;
      encoded_buffer[arg.StructurePtrOffset + 2] = (uint64_t)std::bit_cast<uint32_t>(sampler->lod_bias);
      break;
    }
    case SM50BindingType::SRV: {
      auto slot = 128 * unsigned(stage) + arg.SM50BindingSlot;
      auto &srv = resview_[slot];

      if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_BUFFER) {
        if (srv.buffer.ptr()) {
          auto [srv_alloc, offset] = access<stage>(srv.buffer, srv.slice.byteOffset, srv.slice.byteLength, ResourceAccess::Read);
          encoded_buffer[arg.StructurePtrOffset] = srv_alloc->gpuAddress() + offset + srv.slice.byteOffset;
          encoded_buffer[arg.StructurePtrOffset + 1] = srv.slice.byteLength;
          makeResident<stage, kind>(srv.buffer.ptr());
        } else {
          encoded_buffer[arg.StructurePtrOffset] = 0;
          encoded_buffer[arg.StructurePtrOffset + 1] = 0;
        }
      } else if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE) {
        if (srv.buffer.ptr()) {
          assert(arg.Flags & MTL_SM50_SHADER_ARGUMENT_TBUFFER_OFFSET);
          auto [view, offset] = access<stage>(srv.buffer, srv.viewId, ResourceAccess::Read);
          encoded_buffer[arg.StructurePtrOffset] = view.gpu_resource_id;
          encoded_buffer[arg.StructurePtrOffset + 1] =
              ((uint64_t)srv.slice.elementCount << 32) | (uint64_t)(srv.slice.firstElement + offset);
          makeResident<stage, kind>(srv.buffer.ptr(), srv.viewId);
        } else if (srv.texture.ptr()) {
          assert(arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE_MINLOD_CLAMP);
          auto viewIdChecked = srv.texture->checkViewUseArray(srv.viewId, arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE_ARRAY);
          encoded_buffer[arg.StructurePtrOffset] =
              access<stage>(srv.texture, viewIdChecked, ResourceAccess::Read).gpuResourceID;
          encoded_buffer[arg.StructurePtrOffset + 1] = TextureMetadata(srv.texture->arrayLength(viewIdChecked), 0);
          makeResident<stage, kind>(srv.texture.ptr(), viewIdChecked);
        } else {
          encoded_buffer[arg.StructurePtrOffset] = 0;
          encoded_buffer[arg.StructurePtrOffset + 1] = 0;
        }
      }
      if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_UAV_COUNTER) {
        assert(0 && "srv can not have counter associated");
      }
      break;
    }
    case SM50BindingType::UAV: {
      auto &uav = UAVBindingSet[arg.SM50BindingSlot];
      bool read = (arg.Flags >> 10) & 1, write = (arg.Flags >> 10) & 2;
      int access_flags =  ((arg.Flags >> 10) & 3) | ResourceAccess::UAV;

      if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_BUFFER) {
        if (uav.buffer.ptr()) {
          auto [uav_alloc, offset] = access<stage>(uav.buffer, uav.slice.byteOffset, uav.slice.byteLength, access_flags);
          encoded_buffer[arg.StructurePtrOffset] = uav_alloc->gpuAddress() + offset + uav.slice.byteOffset;
          encoded_buffer[arg.StructurePtrOffset + 1] = uav.slice.byteLength;
          makeResident<stage, kind>(uav.buffer.ptr(), read, write);
        } else {
          encoded_buffer[arg.StructurePtrOffset] = 0;
          encoded_buffer[arg.StructurePtrOffset + 1] = 0;
        }
      } else if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE) {
        if (uav.buffer.ptr()) {
          assert(arg.Flags & MTL_SM50_SHADER_ARGUMENT_TBUFFER_OFFSET);
          auto [view, offset] = access<stage>(uav.buffer, uav.viewId, access_flags);
          encoded_buffer[arg.StructurePtrOffset] = view.gpu_resource_id;
          encoded_buffer[arg.StructurePtrOffset + 1] =
              ((uint64_t)uav.slice.elementCount << 32) | (uint64_t)(uav.slice.firstElement + offset);
          makeResident<stage, kind>(uav.buffer.ptr(), uav.viewId, read, write);
        } else if (uav.texture.ptr()) {
          assert(arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE_MINLOD_CLAMP);
          auto viewIdChecked = uav.texture->checkViewUseArray(uav.viewId, arg.Flags & MTL_SM50_SHADER_ARGUMENT_TEXTURE_ARRAY);
          encoded_buffer[arg.StructurePtrOffset] = access<stage>(uav.texture, viewIdChecked, access_flags).gpuResourceID;
          encoded_buffer[arg.StructurePtrOffset + 1] = TextureMetadata(uav.texture->arrayLength(viewIdChecked), 0);
          makeResident<stage, kind>(uav.texture.ptr(), viewIdChecked, read, write);
        } else {
          encoded_buffer[arg.StructurePtrOffset] = 0;
          encoded_buffer[arg.StructurePtrOffset + 1] = 0;
        }
      }
      if (arg.Flags & MTL_SM50_SHADER_ARGUMENT_UAV_COUNTER) {
        if (uav.counter) {
          auto [counter_alloc, offset] = access<stage>(uav.counter);
          encoded_buffer[arg.StructurePtrOffset + 2] = counter_alloc->gpuAddress() + offset;
          makeResident<stage, kind>(uav.counter.ptr());
        } else {
          /*
           * potentially cause gpu pagefault, even providing a dummy buffer doesn't improve since the returned
           * counter value is likely to be used as an index to another read/write operation.
           */
          encoded_buffer[arg.StructurePtrOffset + 2] = 0;
        }
      }
      break;
    }
    }
  }

  if constexpr (stage == PipelineStage::Compute) {
    auto &cmd = encodeComputeCommand<wmtcmd_compute_setbufferoffset>();
    cmd.type = WMTComputeCommandSetBufferOffset;
    cmd.offset = getFinalArgumentBufferOffset<true>(offset);
    cmd.index = SM50_BINDING_INDEX_ARGUMENT_TABLE;
  } else {
    auto &cmd = encodeRenderCommand<wmtcmd_render_setbufferoffset>();
    cmd.offset = getFinalArgumentBufferOffset(offset);
    cmd.index = SM50_BINDING_INDEX_ARGUMENT_TABLE;
    if constexpr (stage == PipelineStage::Vertex) {
      if constexpr (kind == PipelineKind::Geometry)
        cmd.type = WMTRenderCommandSetObjectBufferOffset;
      else if constexpr (kind == PipelineKind::Tessellation) {
        cmd.type = WMTRenderCommandSetObjectBufferOffset;
        cmd.index = SM50_BINDING_INDEX_ARGUMENT_TABLE2;
      } else
        cmd.type = WMTRenderCommandSetVertexBufferOffset;
    } else if constexpr (stage == PipelineStage::Pixel) {
      cmd.type = WMTRenderCommandSetFragmentBufferOffset;
    } else if constexpr (stage == PipelineStage::Hull) {
      cmd.type = WMTRenderCommandSetObjectBufferOffset;
    } else if constexpr (stage == PipelineStage::Domain) {
      cmd.type = WMTRenderCommandSetMeshBufferOffset;
    } else if constexpr (stage == PipelineStage::Geometry) {
      cmd.type = WMTRenderCommandSetMeshBufferOffset;
    } else {
      assert(0 && "Not implemented or unreachable");
    }
  }
}

CounterAllocation *
ArgumentEncodingContext::getCounterAllocation(Rc<Counter> const &counter) {
  return queue_.counter_pool.getCurrentAllocation(counter);
}

void
ArgumentEncodingContext::retainAllocation(Allocation* allocation) {
  if (allocation->checkRetained(seq_id_))
    return;
  queue_.Retain(seq_id_, allocation);
}

void
ArgumentEncodingContext::clearColor(Rc<Texture> &&texture, uint64_t viewId, unsigned arrayLength, WMTClearColor color) {
  assert(!encoder_current);
  auto encoder_info = allocate<ClearEncoderData>();
  encoder_info->type = EncoderType::Clear;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->clear_dsv = 0;
  encoder_info->color = color;
  SanitizeRTVClearColor(texture->pixelFormat(viewId), encoder_info->color);
  encoder_info->array_length = arrayLength;
  encoder_info->width = texture->width(viewId);
  encoder_info->height = texture->height(viewId);
  encoder_current = encoder_info;

  encoder_info->attachment = access(texture, viewId, ResourceAccess::Write);

  currentFrameStatistics().clear_pass_count++;

  endPass();
}

void
ArgumentEncodingContext::clearDepthStencil(
    Rc<Texture> &&texture, uint64_t viewId, unsigned arrayLength, unsigned flag, float depth, uint8_t stencil
) {
  assert(!encoder_current);
  auto encoder_info = allocate<ClearEncoderData>();
  encoder_info->type = EncoderType::Clear;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->clear_dsv = flag & DepthStencilPlanarFlags(texture->pixelFormat());
  encoder_info->depth_stencil = {depth, stencil};
  encoder_info->array_length = arrayLength;
  encoder_info->width = texture->width(viewId);
  encoder_info->height = texture->height(viewId);
  encoder_current = encoder_info;

  encoder_info->attachment = access(texture, viewId, ResourceAccess::Write);

  currentFrameStatistics().clear_pass_count++;
  
  endPass();
}

void
ArgumentEncodingContext::resolveTexture(
    Rc<Texture> &&src, TextureViewKey src_view, Rc<Texture> &&dst, TextureViewKey dst_view
) {
  assert(!encoder_current);
  auto encoder_info = allocate<ResolveEncoderData>();
  encoder_info->type = EncoderType::Resolve;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_current = encoder_info;

  encoder_info->src = access(src, src_view, ResourceAccess::Read);
  encoder_info->dst = access(dst, dst_view, ResourceAccess::Write);

  endPass();
};

void
ArgumentEncodingContext::present(Rc<Texture> &texture, Rc<Presenter> &presenter, double after, DXMTPresentMetadata metadata) {
  assert(!encoder_current);
  auto encoder_info = allocate<PresentData>();
  encoder_info->type = EncoderType::Present;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->presenter = presenter;
  encoder_info->after = after;
  encoder_info->metadata = metadata;

  encoder_current = encoder_info;
  encoder_info->backbuffer = access(texture, texture->fullView, ResourceAccess::Read).texture;
  endPass();
}

void
ArgumentEncodingContext::upscale(Rc<Texture> &texture, Rc<Texture> &upscaled, Rc<SpatialScaler> &scaler) {
  assert(!encoder_current);
  auto encoder_info = allocate<SpatialUpscaleData>();
  encoder_info->type = EncoderType::SpatialUpscale;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->scaler = scaler;

  encoder_current = encoder_info;
  encoder_info->backbuffer = access(texture, texture->fullView, ResourceAccess::Read).texture;
  encoder_info->upscaled = access(upscaled, upscaled->fullView, ResourceAccess::Write).texture;
  endPass();
}

void
ArgumentEncodingContext::upscaleTemporal(
    Rc<Texture> &input, Rc<Texture> &output, Rc<Texture> &depth, Rc<Texture> &motion_vector, TextureViewKey mvViewId,
    Rc<Texture> &exposure, Rc<TemporalScaler> &scaler, const WMTFXTemporalScalerProps &props
) {
  assert(!encoder_current);
  auto encoder_info = allocate<TemporalUpscaleData>();
  encoder_info->type = EncoderType::TemporalUpscale;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->scaler = scaler;
  encoder_info->props = props;

  encoder_current = encoder_info;
  encoder_info->input = access(input, input->fullView, ResourceAccess::Read).texture;
  encoder_info->depth = access(depth, depth->fullView, ResourceAccess::Read).texture;
  encoder_info->motion_vector = access(motion_vector, mvViewId, ResourceAccess::Read).texture;
  encoder_info->output = access(output, output->fullView, ResourceAccess::Write).texture;
  if (exposure) {
    encoder_info->exposure = access(exposure, exposure->fullView, ResourceAccess::Read).texture;
  }
  endPass();
}

void
ArgumentEncodingContext::signalEvent(uint64_t value) {
  assert(!encoder_current);
  auto encoder_info = allocate<SignalEventData>();
  encoder_info->type = EncoderType::SignalEvent;
  encoder_info->id = ~0ull;
  encoder_info->event = queue_.event;
  encoder_info->value = value;

  encoder_current = encoder_info;
  endPass();
}

void
ArgumentEncodingContext::signalEvent(WMT::Reference<WMT::Event> &&event, uint64_t value) {
  assert(!encoder_current);
  auto encoder_info = allocate<SignalEventData>();
  encoder_info->type = EncoderType::SignalEvent;
  encoder_info->id = ~0ull;
  encoder_info->event = std::move(event);
  encoder_info->value = value;

  encoder_current = encoder_info;
  endPass();
}

void
ArgumentEncodingContext::waitEvent(WMT::Reference<WMT::Event> &&event, uint64_t value) {
  assert(!encoder_current);
  auto encoder_info = allocate<WaitForEventData>();
  encoder_info->type = EncoderType::WaitForEvent;
  encoder_info->id = ~0ull;
  encoder_info->event = std::move(event);
  encoder_info->value = value;

  encoder_current = encoder_info;
  endPass();
}

RenderEncoderData *
ArgumentEncodingContext::startRenderPass(
    uint8_t dsv_planar_flags, uint8_t dsv_readonly_flags, uint8_t render_target_count, uint64_t encoder_argbuf_size
) {
  assert(!encoder_current);
  auto encoder_info = allocate<RenderEncoderData>();
  encoder_info->type = EncoderType::Render;
  encoder_info->encoder_id_vertex = nextEncoderId();
  encoder_info->fence_wait_vertex = {};
  encoder_info->fence_update_vertex = {encoder_info->encoder_id_vertex};
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->cmd_head.type = WMTRenderCommandNop;
  encoder_info->cmd_head.next.set(0);
  encoder_info->cmd_tail = (wmtcmd_base *)&encoder_info->cmd_head;
  encoder_info->dsv_planar_flags = dsv_planar_flags;
  encoder_info->dsv_readonly_flags = dsv_readonly_flags;
  encoder_info->render_target_count = render_target_count;
  auto [gpu_buffer_contents, gpu_buffer_, offset] = queue_.AllocateArgumentBuffer(seq_id_, encoder_argbuf_size);
  encoder_info->allocated_argbuf = gpu_buffer_;
  encoder_info->allocated_argbuf_offset = offset;
  encoder_info->allocated_argbuf_mapping = gpu_buffer_contents;
  encoder_current = encoder_info;

  currentFrameStatistics().render_pass_count++;

  vro_state_.beginEncoder();

  return encoder_info;
}

EncoderData *
ArgumentEncodingContext::startComputePass(uint64_t encoder_argbuf_size) {
  assert(!encoder_current);
  auto encoder_info = allocate<ComputeEncoderData>();
  encoder_info->type = EncoderType::Compute;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->cmd_head.type = WMTComputeCommandNop;
  encoder_info->cmd_head.next.set(0);
  encoder_info->cmd_tail = (wmtcmd_base *)&encoder_info->cmd_head;
  auto [gpu_buffer_contents, gpu_buffer_, offset] = queue_.AllocateArgumentBuffer(seq_id_, encoder_argbuf_size);
  encoder_info->allocated_argbuf = gpu_buffer_;
  encoder_info->allocated_argbuf_offset = offset;
  encoder_info->allocated_argbuf_mapping = gpu_buffer_contents;
  encoder_current = encoder_info;

  currentFrameStatistics().compute_pass_count++;

  return encoder_info;
}

EncoderData *
ArgumentEncodingContext::startBlitPass() {
  assert(!encoder_current);
  auto encoder_info = allocate<BlitEncoderData>();
  encoder_info->type = EncoderType::Blit;
  encoder_info->id = nextEncoderId();
  encoder_info->fence_wait = {};
  encoder_info->fence_update = {encoder_info->id};
  encoder_info->cmd_head.type = WMTBlitCommandNop;
  encoder_info->cmd_head.next.set(0);
  encoder_info->cmd_tail = (wmtcmd_base *)&encoder_info->cmd_head;
  encoder_current = encoder_info;

  currentFrameStatistics().blit_pass_count++;

  return encoder_info;
}

void
ArgumentEncodingContext::endPass() {
  assert(encoder_current);
  encoder_last->next = encoder_current;
  encoder_last = encoder_current;

  if (encoder_current->id != ~0ull) {
    if (encoder_current->type == EncoderType::Render) {
      vro_state_.endEncoder();
      auto render_encoder = static_cast<RenderEncoderData *>(encoder_current);

      if (render_encoder->depth.attachment && !(render_encoder->dsv_readonly_flags & 1))
        access<PipelineStage::Pixel>(
            render_encoder->depth.attachment->allocation->descriptor, render_encoder->depth.attachment->key,
            ResourceAccess::Write
        );
      if (render_encoder->stencil.attachment && !(render_encoder->dsv_readonly_flags & 2))
        access<PipelineStage::Pixel>(
            render_encoder->stencil.attachment->allocation->descriptor, render_encoder->stencil.attachment->key,
            ResourceAccess::Write
        );

      render_encoder->fence_wait_vertex =
          fence_locality_.collectAndSimplifyWaits(render_encoder->fence_wait_vertex, render_encoder->encoder_id_vertex);
      encoder_current->fence_wait =
          fence_locality_.collectAndSimplifyWaits(encoder_current->fence_wait, encoder_last->id, true);
    } else {
      encoder_current->fence_wait =
          fence_locality_.collectAndSimplifyWaits(encoder_current->fence_wait, encoder_last->id);
    }
  }

  encoder_current = nullptr;
  encoder_count_++;
}

std::pair<WMT::Buffer, size_t>
ArgumentEncodingContext::allocateTempBuffer(size_t size, size_t alignment) {
  return queue_.AllocateTempBuffer(seq_id_, size, alignment);
};

AllocatedTempBufferSlice
ArgumentEncodingContext::allocateTempBuffer1(size_t size, size_t alignment) {
  return queue_.AllocateTempBuffer1(seq_id_, size, alignment);
};

void
ArgumentEncodingContext::beginVisibilityResultQuery(Rc<VisibilityResultQuery> &&query) {
  query->begin(seq_id_, vro_state_.getNextReadOffset());
  active_visibility_query_count_++;
  pending_queries_.push_back(std::move(query));
}
void
ArgumentEncodingContext::endVisibilityResultQuery(Rc<VisibilityResultQuery> &&query) {
  query->end(seq_id_, vro_state_.getNextReadOffset());
  assert(active_visibility_query_count_);
  active_visibility_query_count_--;
}
void
ArgumentEncodingContext::bumpVisibilityResultOffset() {
  auto render_encoder = currentRenderEncoder();
  render_encoder->use_visibility_result = render_encoder->use_visibility_result || bool(active_visibility_query_count_);

  uint64_t offset;
  if (vro_state_.tryGetNextWriteOffset(active_visibility_query_count_, offset)) {
    auto &cmd = encodeRenderCommand<wmtcmd_render_setvisibilitymode>();
    cmd.type = WMTRenderCommandSetVisibilityMode;
    if (~offset == 0) {
      cmd.mode = WMTVisibilityResultModeDisabled;
      cmd.offset = 0;
    } else {
      cmd.mode = WMTVisibilityResultModeCounting;
      cmd.offset = offset << 3;
    }
  }
}

FrameStatistics&
ArgumentEncodingContext::currentFrameStatistics() {
  return queue_.statistics.at(frame_id_);
}

void
ArgumentEncodingContext::sampleTimestamp(Rc<TimestampQuery> &&query) {
  assert(!encoder_current);
  if (encoder_last && encoder_last->type == EncoderType::SampleTimestamp) {
    timestamp_state_.coalesceQuery(query.ptr());
    static_cast<SampleTimestampData *>(encoder_last)->queries.push_back(std::move(query));
    return;
  }
  auto encoder_info = allocate<SampleTimestampData>();
  encoder_info->type = EncoderType::SampleTimestamp;
  encoder_info->id = ~0ull;
  encoder_info->readback_index = timestamp_state_.addQuery(query.ptr());
  encoder_info->queries = {};
  encoder_info->queries.push_back(std::move(query));

  encoder_current = encoder_info;
  endPass();
}

void
ArgumentEncodingContext::resolveComputePassBarrier() {
  assert(encoder_current);
  assert(encoder_current->type == EncoderType::Compute);
  auto &barrier_state = encoder_current->barrier_state;
  if (barrier_state.barrierSet & ~intrapass_barrier_control_bits_) {
    auto &cmd = encodeComputeCommand<wmtcmd_compute_memory_barrier>();
    cmd.type = WMTComputeCommandMemoryBarrier;
    cmd.scope = WMTBarrierScopeBuffers | WMTBarrierScopeTextures;
    barrier_state.barrierSet = 0;
  }
}

void
ArgumentEncodingContext::resolveRenderPassBarrier() {
  assert(encoder_current);
  assert(encoder_current->type == EncoderType::Render);
  auto &barrier_state = encoder_current->barrier_state;
  if (barrier_state.barrierPreRasterAfterFragmentSet & ~intrapass_barrier_control_bits_) {
    // TODO(barrier): encoder split
    WARN("A fragment-vertex barrier is omitted");
    barrier_state.barrierSet = 0;
    barrier_state.barrierPreRasterSet = 0;
    barrier_state.barrierFragmentAfterPreRasterSet = 0;
    barrier_state.barrierPreRasterAfterFragmentSet = 0;
    return;
  }
  // Individual barriers
  if (barrier_state.barrierSet & ~intrapass_barrier_control_bits_) {
    tile_barrier_cmd.dispatch();
    barrier_state.barrierSet = 0;
  }
  if (barrier_state.barrierPreRasterSet & ~intrapass_barrier_control_bits_) {
    auto &cmd = encodeRenderCommand<wmtcmd_render_memory_barrier>();
    cmd.type = WMTRenderCommandMemoryBarrier;
    cmd.scope = WMTBarrierScopeBuffers | WMTBarrierScopeTextures;
    cmd.stages_before = WMTRenderStagePreRaster;
    cmd.stages_after = WMTRenderStagePreRaster;
    barrier_state.barrierPreRasterSet = 0;
  }
  if (barrier_state.barrierFragmentAfterPreRasterSet & ~intrapass_barrier_control_bits_) {
    auto &cmd = encodeRenderCommand<wmtcmd_render_memory_barrier>();
    cmd.type = WMTRenderCommandMemoryBarrier;
    cmd.scope = WMTBarrierScopeBuffers | WMTBarrierScopeTextures;
    cmd.stages_before = WMTRenderStageFragment;
    cmd.stages_after = WMTRenderStagePreRaster;
    barrier_state.barrierFragmentAfterPreRasterSet = 0;
  }
}

void
ArgumentEncodingContext::$$setEncodingContext(uint64_t seq_id, uint64_t frame_id) {
  current_buffer_chunk_ = 0;
  cpu_buffer_ = cpu_buffer_chunks_[current_buffer_chunk_].ptr;
  cpu_buffer_offset_ = 0;
  seq_id_ = seq_id;
  frame_id_ = frame_id;
}

constexpr unsigned kEncoderOptimizerThreshold = 64;

QueryReadbacks
ArgumentEncodingContext::flushCommands(WMT::CommandBuffer cmdbuf, uint64_t seqId, uint64_t event_seq_id) {
  assert(!encoder_current);

  unsigned encoder_count = encoder_count_;
  unsigned encoder_index = 0;
  EncoderData **encoders =
      reinterpret_cast<EncoderData **>(allocate_cpu_heap(sizeof(EncoderData *) * encoder_count, alignof(EncoderData *))
      );

  {
    EncoderData *current = encoder_head.next;
    while (current) {
      encoders[encoder_index++] = current;
      current = current->next;
    }
    assert(encoder_index == encoder_count);
  }

  if (encoder_count > 1) {
    unsigned j, i;
    for (j = encoder_count - 2; j != ~0u; j--) {
      // TODO(fences): we don't actively move encoders other than clear and render
      if (encoders[j]->type != EncoderType::Clear && encoders[j]->type != EncoderType::Render)
        continue;
      for (i = j + 1; i < encoder_count; i++) {
        if (encoders[i]->type == EncoderType::Null)
          continue;
        if (checkEncoderRelation(encoders[j], encoders[i]) == DXMT_ENCODER_LIST_OP_SYNCHRONIZE)
          break;
      }
    }
  }

  QueryReadbacks readbacks{};

  if (auto count = vro_state_.reset()) {
    readbacks.visibility = std::make_unique<VisibilityResultReadback>(
        device_, seqId, count, pending_queries_
    );
  }
  std::erase_if(pending_queries_, [=](auto &query) -> bool { return query->queryEndAt() == seqId; });

  readbacks.timestamp = timestamp_state_.flush(cmdbuf);

  while (encoder_index) {
    auto current = encoders[encoder_count - encoder_index];
    switch (current->type) {
    case EncoderType::Render: {
      auto data = static_cast<RenderEncoderData *>(current);
      WMTRenderPassInfo render_pass_info;
      WMT::InitializeRenderPassInfo(render_pass_info);
      {
        for (unsigned i = 0; i < std::size(render_pass_info.colors); i++) {
          auto &color_data = data->colors[i];
          if (!color_data.attachment)
            continue;
          auto &color_info = render_pass_info.colors[i];
          color_info.texture = color_data.attachment.texture();
          color_info.load_action = color_data.load_action;
          color_info.store_action = color_data.store_action;
          color_info.level = color_data.level;
          color_info.slice = color_data.slice;
          color_info.depth_plane = color_data.depth_plane;
          color_info.clear_color = color_data.clear_color;
          color_info.resolve_texture = color_data.resolve_attachment.texture();
          color_info.resolve_level = color_data.resolve_level;
          color_info.resolve_slice = color_data.resolve_slice;
          color_info.resolve_depth_plane = color_data.resolve_depth_plane;
        }
        if (data->depth.attachment) {
          auto &depth_info = render_pass_info.depth;
          auto &depth_data = data->depth;
          depth_info.texture = depth_data.attachment.texture();
          depth_info.load_action = depth_data.load_action;
          depth_info.store_action = depth_data.store_action;
          depth_info.level = depth_data.level;
          depth_info.slice = depth_data.slice;
          depth_info.depth_plane = depth_data.depth_plane;
          depth_info.clear_depth = depth_data.clear_depth;
        }
        if (data->stencil.attachment) {
          auto &stencil_info = render_pass_info.stencil;
          auto &stencil_data = data->stencil;
          stencil_info.texture = stencil_data.attachment.texture();
          stencil_info.load_action = stencil_data.load_action;
          stencil_info.store_action = stencil_data.store_action;
          stencil_info.level = stencil_data.level;
          stencil_info.slice = stencil_data.slice;
          stencil_info.depth_plane = stencil_data.depth_plane;
          stencil_info.clear_stencil = stencil_data.clear_stencil;
        }
        render_pass_info.default_raster_sample_count = data->default_raster_sample_count;
        render_pass_info.render_target_array_length = data->render_target_array_length;
        render_pass_info.render_target_width = data->render_target_width;
        render_pass_info.render_target_height = data->render_target_height;
      }
      if (data->use_visibility_result) {
        assert(readbacks.visibility);
        render_pass_info.visibility_buffer = readbacks.visibility->visibility_result_heap;
      }
      auto gpu_buffer_ = data->allocated_argbuf;
      auto encoder = cmdbuf.renderCommandEncoder(render_pass_info);
      data->fence_wait.forEach(
          data->fence_wait_vertex, // if a fence is waited pre-raster, no need to wait again at fragment
          [&](auto id) { encoder.waitForFence(fence_pool_[id], WMTRenderStagePreRaster); },
          [&](auto id) { encoder.waitForFence(fence_pool_[id], WMTRenderStageFragment); }
      );
      encoder.setVertexBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_VERTEX_BUFFER);
      encoder.setVertexBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_CONSTANT_BUFFER);
      encoder.setVertexBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_ARGUMENT_TABLE);
      if (data->use_emulated_so)
        encoder.setVertexBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_STREAM_OUTPUT0);
      encoder.setFragmentBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_CONSTANT_BUFFER);
      encoder.setFragmentBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_ARGUMENT_TABLE);
      if (data->use_geometry || data->use_tessellation) {
        encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_VERTEX_BUFFER);
        encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_DRAW_ARGUMENTS);
        if (data->use_tessellation) {
          encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_CONSTANT_BUFFER2);
          encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_ARGUMENT_TABLE2);
        }
        encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_CONSTANT_BUFFER);
        encoder.setObjectBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_ARGUMENT_TABLE);
        encoder.setMeshBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_CONSTANT_BUFFER);
        encoder.setMeshBuffer(gpu_buffer_, 0, SM50_BINDING_INDEX_ARGUMENT_TABLE);
      }
      if (data->gs_arg_marshal_tasks.size()) {
        auto task_count = data->gs_arg_marshal_tasks.size();
        struct GS_MARSHAL_TASK {
          uint64_t draw_args;
          uint64_t dispatch_args_out;
          uint64_t max_object_threadgroups;
          uint32_t vertex_count_per_warp;
          uint32_t end_of_command;
        };
        auto [mapped_task_data, task_data_buffer, task_data_buffer_offset] =
            queue_.AllocateArgumentBuffer(seq_id_, sizeof(GS_MARSHAL_TASK) * task_count);
        auto tasks_data = (GS_MARSHAL_TASK *)mapped_task_data;
        for (unsigned i = 0; i<task_count; i++) {
          auto & task = data->gs_arg_marshal_tasks[i];
          tasks_data[i].draw_args = task.draw_arguments_va;
          tasks_data[i].dispatch_args_out = task.dispatch_arguments_va;
          tasks_data[i].max_object_threadgroups = task.max_object_threadgroups;
          tasks_data[i].vertex_count_per_warp = task.vertex_count_per_warp;
          tasks_data[i].end_of_command = 0;
          encoder.useResource(task.draw_arguments, WMTResourceUsageRead, WMTRenderStageVertex);
          encoder.useResource(task.dispatch_arguments_buffer, WMTResourceUsageWrite, WMTRenderStageVertex);
        }
        tasks_data[task_count - 1].end_of_command = 1;
        emulated_cmd.MarshalGSDispatchArguments(encoder, task_data_buffer, task_data_buffer_offset);
      }
      if (data->ts_arg_marshal_tasks.size()) {
        auto task_count = data->ts_arg_marshal_tasks.size();
        struct TS_MARSHAL_TASK {
          uint64_t draw_args;
          uint64_t dispatch_args_out;
          uint64_t max_object_threadgroups;
          uint16_t control_point_count;
          uint16_t patch_per_group;
          uint32_t end_of_command;
        };
        auto [mapped_task_data, task_data_buffer, task_data_buffer_offset] =
            queue_.AllocateArgumentBuffer(seq_id_, sizeof(TS_MARSHAL_TASK) * task_count);
        auto tasks_data = (TS_MARSHAL_TASK *)mapped_task_data;
        for (unsigned i = 0; i<task_count; i++) {
          auto & task = data->ts_arg_marshal_tasks[i];
          tasks_data[i].draw_args = task.draw_arguments_va;
          tasks_data[i].dispatch_args_out = task.dispatch_arguments_va;
          tasks_data[i].max_object_threadgroups = task.max_object_threadgroups;
          tasks_data[i].control_point_count = task.control_point_count;
          tasks_data[i].patch_per_group = task.patch_per_group;
          tasks_data[i].end_of_command = 0;
          encoder.useResource(task.draw_arguments, WMTResourceUsageRead, WMTRenderStageVertex);
          encoder.useResource(task.dispatch_arguments_buffer, WMTResourceUsageWrite, WMTRenderStageVertex);
        }
        tasks_data[task_count - 1].end_of_command = 1;
        emulated_cmd.MarshalTSDispatchArguments(encoder, task_data_buffer, task_data_buffer_offset);
      }
      if (data->gs_arg_marshal_tasks.size() > 0 || data->ts_arg_marshal_tasks.size() > 0) {
        encoder.memoryBarrier(
            WMTBarrierScopeBuffers, WMTRenderStageVertex,
            WMTRenderStageVertex | WMTRenderStageMesh | WMTRenderStageObject
        );
      }
      encoder.encodeCommands(&data->cmd_head);
      data->fence_update_vertex.forEach(
          data->fence_update, // if a fence is updated at fragment, no need to update again pre-raster
          [&](auto id) { encoder.updateFence(fence_pool_[id], WMTRenderStageFragment); },
          [&](auto id) { encoder.updateFence(fence_pool_[id], WMTRenderStagePreRaster); }
      );
      encoder.endEncoding();
      data->~RenderEncoderData();
      break;
    }
    case EncoderType::Compute: {
      auto data = static_cast<ComputeEncoderData *>(current);
      auto encoder = cmdbuf.computeCommandEncoder(true);
      data->fence_wait.forEach([&](auto id) { encoder.waitForFence(fence_pool_[id]); });
      struct wmtcmd_compute_setbuffer setcmd;
      setcmd.type = WMTComputeCommandSetBuffer;
      setcmd.next.set(nullptr);
      setcmd.buffer = data->allocated_argbuf;
      setcmd.offset = 0;
      setcmd.index = SM50_BINDING_INDEX_CONSTANT_BUFFER;
      encoder.encodeCommands((const wmtcmd_compute_nop *)&setcmd);
      setcmd.index = SM50_BINDING_INDEX_ARGUMENT_TABLE;
      encoder.encodeCommands((const wmtcmd_compute_nop *)&setcmd);
      encoder.encodeCommands(&data->cmd_head);
      data->fence_update.forEach([&](auto id) { encoder.updateFence(fence_pool_[id]); });
      encoder.endEncoding();
      data->~ComputeEncoderData();
      break;
    }
    case EncoderType::Blit: {
      auto data = static_cast<BlitEncoderData *>(current);
      auto encoder = cmdbuf.blitCommandEncoder();
      data->fence_wait.forEach([&](auto id) { encoder.waitForFence(fence_pool_[id]); });
      encoder.encodeCommands(&data->cmd_head);
      data->fence_update.forEach([&](auto id) { encoder.updateFence(fence_pool_[id]); });
      encoder.endEncoding();
      data->~BlitEncoderData();
      break;
    }
    case EncoderType::Present: {
      auto data = static_cast<PresentData *>(current);
      auto t0 = clock::now();
      auto drawable = data->presenter->encodeCommands(
          cmdbuf, data->backbuffer, data->metadata,
          [&](WMT::RenderCommandEncoder encoder) {
            data->fence_wait.forEach([&](auto id) { encoder.waitForFence(fence_pool_[id], WMTRenderStageFragment); });
          },
          [&](WMT::RenderCommandEncoder encoder) {
            data->fence_update.forEach([&](auto id) { encoder.updateFence(fence_pool_[id], WMTRenderStageFragment); });
          }
      );
      auto t1 = clock::now();
      currentFrameStatistics().drawable_blocking_interval += (t1 - t0);
      if (data->after > 0)
        cmdbuf.presentDrawableAfterMinimumDuration(drawable, data->after);
      else
        cmdbuf.presentDrawable(drawable);
      data->~PresentData();
      break;
    }
    case EncoderType::Clear: {
      auto data = static_cast<ClearEncoderData *>(current);
      {
        WMTRenderPassInfo info;
        WMT::InitializeRenderPassInfo(info);
        if (data->clear_dsv) {
          if (data->clear_dsv & 1) {
            info.depth.clear_depth = data->depth_stencil.first;
            info.depth.texture = data->attachment.texture();
            info.depth.load_action = WMTLoadActionClear;
            info.depth.store_action = WMTStoreActionStore;
          }
          if (data->clear_dsv & 2) {
            info.stencil.clear_stencil = data->depth_stencil.second;
            info.stencil.texture = data->attachment.texture();
            info.stencil.load_action = WMTLoadActionClear;
            info.stencil.store_action = WMTStoreActionStore;
          }
          info.render_target_width = data->width;
          info.render_target_height = data->height;
        } else {
          info.colors[0].clear_color = data->color;
          info.colors[0].texture = data->attachment.texture();
          info.colors[0].load_action = WMTLoadActionClear;
          info.colors[0].store_action = WMTStoreActionStore;
        }
        info.render_target_array_length = data->array_length;
        auto encoder = cmdbuf.renderCommandEncoder(info);
        encoder.setLabel(WMT::String::string("ClearPass", WMTUTF8StringEncoding));
        data->fence_wait.forEach([&](auto id) { encoder.waitForFence(fence_pool_[id], WMTRenderStageFragment); });
        data->fence_update.forEach([&](auto id) { encoder.updateFence(fence_pool_[id], WMTRenderStageFragment); });
        encoder.endEncoding();
      }
      data->~ClearEncoderData();
      break;
    }
    case EncoderType::Resolve: {
      auto data = static_cast<ResolveEncoderData *>(current);
      {
        WMTRenderPassInfo info;
        WMT::InitializeRenderPassInfo(info);
        info.colors[0].texture = data->src.texture();
        info.colors[0].load_action = WMTLoadActionLoad;
        info.colors[0].store_action = WMTStoreActionStoreAndMultisampleResolve;
        info.colors[0].resolve_texture = data->dst.texture();

        auto encoder = cmdbuf.renderCommandEncoder(info);
        encoder.setLabel(WMT::String::string("ResolvePass", WMTUTF8StringEncoding));
        data->fence_wait.forEach([&](auto id) { encoder.waitForFence(fence_pool_[id], WMTRenderStageFragment); });
        data->fence_update.forEach([&](auto id) { encoder.updateFence(fence_pool_[id], WMTRenderStageFragment); });
        encoder.endEncoding();
      }
      data->~ResolveEncoderData();
      break;
    }
    case EncoderType::SpatialUpscale: {
      auto data = static_cast<SpatialUpscaleData *>(current);

      auto begin_scaler = cmdbuf.blitCommandEncoder();
      begin_scaler.setLabel(WMT::String::string("BeginScaler", WMTUTF8StringEncoding));
      data->fence_wait.forEach([&](auto id) { begin_scaler.waitForFence(fence_pool_[id]); });
      begin_scaler.updateFence(data->scaler->fence());
      begin_scaler.endEncoding();

      cmdbuf.encodeSpatialScale(data->scaler->scaler(), data->backbuffer, data->upscaled, data->scaler->fence());

      auto end_scaler = cmdbuf.blitCommandEncoder();
      end_scaler.waitForFence(data->scaler->fence());
      end_scaler.setLabel(WMT::String::string("EndScaler", WMTUTF8StringEncoding));
      data->fence_update.forEach([&](auto id) { end_scaler.updateFence(fence_pool_[id]); });
      end_scaler.endEncoding();

      data->~SpatialUpscaleData();
      break;
    }
    case EncoderType::SignalEvent: {
      auto data = static_cast<SignalEventData *>(current);
      cmdbuf.encodeSignalEvent(data->event, data->value);
      data->~SignalEventData();
      break;
    }
    case EncoderType::WaitForEvent: {
      auto data = static_cast<WaitForEventData *>(current);
      cmdbuf.encodeWaitForEvent(data->event, data->value);
      data->~WaitForEventData();
      break;
    }
    case EncoderType::TemporalUpscale: {
      auto data = static_cast<TemporalUpscaleData *>(current);

      auto begin_scaler = cmdbuf.blitCommandEncoder();
      begin_scaler.setLabel(WMT::String::string("BeginScaler", WMTUTF8StringEncoding));
      data->fence_wait.forEach([&](auto id) { begin_scaler.waitForFence(fence_pool_[id]); });
      begin_scaler.updateFence(data->scaler->fence());
      begin_scaler.endEncoding();

      cmdbuf.encodeTemporalScale(
          data->scaler->scaler(), data->input, data->output, data->depth, data->motion_vector, data->exposure,
          data->scaler->fence(), data->props
      );

      auto end_scaler = cmdbuf.blitCommandEncoder();
      end_scaler.waitForFence(data->scaler->fence());
      end_scaler.setLabel(WMT::String::string("EndScaler", WMTUTF8StringEncoding));
      data->fence_update.forEach([&](auto id) { end_scaler.updateFence(fence_pool_[id]); });
      end_scaler.endEncoding();
      data->~TemporalUpscaleData();
      break;
    }
    case EncoderType::SampleTimestamp: {
      auto data = static_cast<SampleTimestampData *>(current);
      if (auto readback = readbacks.timestamp.get(); readback->sampleBuffer()) {

        /**
        Since Metal driver may change the execution order of encoders, implement a "barrier" to prevent that
        FIXME: Not an elegant implementation, should get rid of it when fence-based synchronization is done
        */
        barrierOnQueue(cmdbuf);

        WMTSampleBufferAttachmentInfo sample_buffer_info{};
        sample_buffer_info.sample_buffer = readback->sampleBuffer();
        sample_buffer_info.start_of_encoder_sample_index = data->readback_index;
        sample_buffer_info.end_of_encoder_sample_index = ~0ull; /* MTLCounterDontSample */
        auto encoder = cmdbuf.blitCommandEncoderWithSampleBuffers(&sample_buffer_info, 1);
        encoder.setLabel(WMT::String::string("SampleTimestamp", WMTUTF8StringEncoding));
        {
          /**
          `sampleBufferAttachments` does not work when the blit encoder is empty, just do something
          FIXME: potential perf overhead? 
          */
          struct wmtcmd_blit_fillbuffer fill;
          fill.next.set(nullptr);
          fill.type = WMTBlitCommandFillBuffer;
          fill.buffer = dummy_cbuffer_;
          fill.offset = 0;
          fill.length = 4;
          fill.value = 0;
          MTLBlitCommandEncoder_encodeCommands(encoder, (const struct wmtcmd_base *)&fill);
        }
        encoder.endEncoding();

      } else {
        // Use timestamp from command buffer's `gpuEndTime`
      }
      data->~SampleTimestampData();
      break;
    }
    default:
      break;
    }
    encoder_index--;
  }
  encoder_head.next = nullptr;
  encoder_last = &encoder_head;
  encoder_count_ = 0;

  cmdbuf.encodeSignalEvent(queue_.event, event_seq_id);

  for (size_t i = cpu_buffer_chunks_.size() - 1; i > current_buffer_chunk_; i--) {
    if (++cpu_buffer_chunks_[i].underused_times > kEncodingContextCPUHeapLifetime) {
      cpu_buffer_chunks_.pop_back();
    }
  }

  return readbacks;
}

DXMT_ENCODER_LIST_OP
ArgumentEncodingContext::checkEncoderRelation(EncoderData *former, EncoderData *latter) {

  if (former->type == EncoderType::Null)
    return DXMT_ENCODER_LIST_OP_SWAP;
  if (latter->type == EncoderType::Null)
    return DXMT_ENCODER_LIST_OP_SWAP;
  if (former->type == EncoderType::SignalEvent)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
  if (latter->type == EncoderType::SignalEvent)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
  if (former->type == EncoderType::WaitForEvent)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
  if (latter->type == EncoderType::WaitForEvent)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
  if (former->type == EncoderType::SampleTimestamp)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
  if (latter->type == EncoderType::SampleTimestamp)
    return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;

  while (former->type != latter->type) {
    if (former->type == EncoderType::Clear && latter->type == EncoderType::Render) {
      auto render = reinterpret_cast<RenderEncoderData *>(latter);
      auto clear = reinterpret_cast<ClearEncoderData *>(former);

      if (render->render_target_array_length != clear->array_length)
        break;

      if (clear->clear_dsv) {
        if (auto depth_attachment = isClearDepthSignatureMatched(clear, render)) {
          if (depth_attachment->load_action == WMTLoadActionLoad) {
            depth_attachment->clear_depth = clear->depth_stencil.first;
            depth_attachment->load_action = WMTLoadActionClear;
          }
          clear->clear_dsv &= ~1;
        }
        if (auto stencil_attachment = isClearStencilSignatureMatched(clear, render)) {
          if (stencil_attachment->load_action == WMTLoadActionLoad) {
            stencil_attachment->clear_stencil = clear->depth_stencil.second;
            stencil_attachment->load_action = WMTLoadActionClear;
          }
          clear->clear_dsv &= ~2;
        }
        if (clear->clear_dsv == 0) {
          render->fence_update.merge(clear->fence_update);
          render->fence_wait.merge(clear->fence_wait);
          render->fence_wait.subtract(clear->fence_update);
          currentFrameStatistics().clear_pass_optimized++;
          clear->~ClearEncoderData();
          clear->next = nullptr;
          clear->type = EncoderType::Null;
          return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
        }
      } else {
        if (auto attachment = isClearColorSignatureMatched(clear, render)) {
          if (attachment->load_action == WMTLoadActionLoad) {
            attachment->load_action = WMTLoadActionClear;
            attachment->clear_color = clear->color;
          }
          render->fence_update.merge(clear->fence_update);
          render->fence_wait.merge(clear->fence_wait);
          render->fence_wait.subtract(clear->fence_update);
          currentFrameStatistics().clear_pass_optimized++;
          clear->~ClearEncoderData();
          clear->next = nullptr;
          clear->type = EncoderType::Null;
          return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
        }
      }
      break;
    }
    if (latter->type == EncoderType::Clear && former->type == EncoderType::Render) {
      auto render = reinterpret_cast<RenderEncoderData *>(former);
      auto clear = reinterpret_cast<ClearEncoderData *>(latter);

      // DontCare can be used because it's going to be cleared anyway
      // just keep in mind DontCare != DontStore
      if (clear->clear_dsv & 1 && render->depth.attachment == clear->attachment)
        render->depth.store_action = WMTStoreActionDontCare;
      if (clear->clear_dsv & 2 && render->stencil.attachment == clear->attachment)
        render->stencil.store_action = WMTStoreActionDontCare;
    }
    if (former->type == EncoderType::Render && latter->type == EncoderType::Resolve) {
      auto render = reinterpret_cast<RenderEncoderData *>(former);
      auto resolve = reinterpret_cast<ResolveEncoderData *>(latter);
      auto result = isResolveSignatureMatched(render, resolve);
      if (result.src) {
        result.src->store_action = WMTStoreActionStoreAndMultisampleResolve;
        result.src->resolve_attachment = result.dst;
        render->fence_update.merge(resolve->fence_update);
        render->fence_wait.merge(resolve->fence_wait);
        render->fence_wait.subtract(resolve->fence_update);

        currentFrameStatistics().resolve_pass_optimized++;
        resolve->~ResolveEncoderData();
        resolve->next = nullptr;
        resolve->type = EncoderType::Null;
        return DXMT_ENCODER_LIST_OP_SWAP; // carry on (RENDER -> RESOLVE -> RESOLVE -> ...)
      }
    }
    return hasDataDependency(latter, former) ? DXMT_ENCODER_LIST_OP_SYNCHRONIZE : DXMT_ENCODER_LIST_OP_SWAP;
  }

  if (former->type == EncoderType::Render) {
    auto r1 = reinterpret_cast<RenderEncoderData *>(latter);
    auto r0 = reinterpret_cast<RenderEncoderData *>(former);

    if (isEncoderSignatureMatched(r0, r1) &&
        // can't merge if latter's vertex wait for former's fragment
        !r1->fence_wait_vertex.intersectedWith(r0->fence_update)) {
      for (unsigned i = 0; i < r0->render_target_count; i++) {
        auto &a0 = r0->colors[i];
        auto &a1 = r1->colors[i];
        a1.load_action = a0.load_action;
        a1.clear_color = a0.clear_color;
      }

      r1->depth.load_action = r0->depth.load_action;
      r1->depth.clear_depth = r0->depth.clear_depth;
      r1->depth.store_action = r0->depth.store_action;
      r1->stencil.load_action = r0->stencil.load_action;
      r1->stencil.clear_stencil = r0->stencil.clear_stencil;
      r1->stencil.store_action = r0->stencil.store_action;

      if ((void *)r0->cmd_tail != &r0->cmd_head) {
        r0->cmd_tail->next.set(r1->cmd_head.next.get());
        r1->cmd_head.next.set(r0->cmd_head.next.get());
        r0->cmd_head.next.set(nullptr);
        r0->cmd_tail = (wmtcmd_base *)&r0->cmd_head;
      }
      r1->use_tessellation = r0->use_tessellation || r1->use_tessellation;
      r1->use_geometry = r0->use_geometry || r1->use_geometry;
      r1->use_emulated_so = r0->use_emulated_so || r1->use_emulated_so;
      std::move(
        r1->gs_arg_marshal_tasks.begin(),
        r1->gs_arg_marshal_tasks.end(),
        std::back_inserter(r0->gs_arg_marshal_tasks)
      );
      std::move(
        r1->ts_arg_marshal_tasks.begin(),
        r1->ts_arg_marshal_tasks.end(),
        std::back_inserter(r0->ts_arg_marshal_tasks)
      );
      r1->gs_arg_marshal_tasks = std::move(r0->gs_arg_marshal_tasks);
      r1->ts_arg_marshal_tasks = std::move(r0->ts_arg_marshal_tasks);
      r1->use_visibility_result = r0->use_visibility_result || r1->use_visibility_result;

      r1->fence_update.merge(r0->fence_update);
      r1->fence_wait.merge(r0->fence_wait);
      r1->fence_wait.subtract(r0->fence_update);
      r1->fence_update_vertex.merge(r0->fence_update_vertex);
      r1->fence_wait_vertex.merge(r0->fence_wait_vertex);
      r1->fence_wait_vertex.subtract(r0->fence_update_vertex);

      // just in case
      r1->fence_wait.subtract(r0->fence_update_vertex);
      /* 
      r1->fence_wait_vertex.subtract(r0->fence_update);
      does not make sense
      */

      currentFrameStatistics().render_pass_optimized++;
      r0->~RenderEncoderData();
      r0->next = nullptr;
      r0->type = EncoderType::Null;

      return DXMT_ENCODER_LIST_OP_SYNCHRONIZE;
    }
  }

  return hasDataDependency(latter, former) ? DXMT_ENCODER_LIST_OP_SYNCHRONIZE : DXMT_ENCODER_LIST_OP_SWAP;
}

bool
ArgumentEncodingContext::hasDataDependency(EncoderData *latter, EncoderData *former) {
  if (former->type == EncoderType::Render) {
    auto r0 = reinterpret_cast<RenderEncoderData *>(former);
    FenceSet fence_wait_r0 = r0->fence_wait.unionOf(r0->fence_wait_vertex);
    FenceSet fence_update_r0 = r0->fence_update_vertex.unionOf(r0->fence_update);
    if (latter->type == EncoderType::Render) {
      auto r1 = reinterpret_cast<RenderEncoderData *>(latter);
      FenceSet fence_wait_r1 = r1->fence_wait.unionOf(r1->fence_wait_vertex);
      FenceSet fence_update_r1 = r1->fence_update_vertex.unionOf(r1->fence_update);
      return fence_update_r0.intersectedWith(fence_wait_r1) || fence_update_r1.intersectedWith(fence_wait_r0);
    }
    return fence_update_r0.intersectedWith(latter->fence_wait) || latter->fence_update.intersectedWith(fence_wait_r0);
  }
  if (latter->type == EncoderType::Render) {
    auto r1 = reinterpret_cast<RenderEncoderData *>(latter);
    FenceSet fence_wait = r1->fence_wait.unionOf(r1->fence_wait_vertex);
    FenceSet fence_update = r1->fence_update_vertex.unionOf(r1->fence_update);
    return former->fence_update.intersectedWith(fence_wait) || fence_update.intersectedWith(former->fence_wait);
  }
  return former->fence_update.intersectedWith(latter->fence_wait) ||
         latter->fence_update.intersectedWith(former->fence_wait);
}

bool
ArgumentEncodingContext::isEncoderSignatureMatched(RenderEncoderData *r0, RenderEncoderData *r1) {
  // FIXME: it can be different?
  if (r0->render_target_count != r1->render_target_count)
    return false;
  if (r0->dsv_planar_flags != r1->dsv_planar_flags)
    return false;
  if (r0->dsv_readonly_flags != r1->dsv_readonly_flags)
    return false;
  if (r0->render_target_array_length != r1->render_target_array_length)
    return false;
  /**
  In case two encoder has different argument buffer
  It can be further optimized by inserting extra setBuffer() calls
  but let's just simplify it, as it's a rather rare case.
  */
  if (r0->allocated_argbuf != r1->allocated_argbuf)
    return false;
  if (r0->dsv_planar_flags & 1) {
    if (r0->depth.attachment != r1->depth.attachment)
      return false;
    if (r0->dsv_readonly_flags & 1) {
      if (r1->depth.load_action == WMTLoadActionClear)
        return false;
    } else {
      if (r0->depth.store_action != WMTStoreActionStore)
        return false;
      if (r1->depth.load_action != WMTLoadActionLoad)
        return false;
    }
  }
  if (r0->dsv_planar_flags & 2) {
    if (r0->stencil.attachment != r1->stencil.attachment)
      return false;
    if (r0->dsv_readonly_flags & 2) {
      if (r1->stencil.load_action == WMTLoadActionClear)
        return false;
    } else {
      if (r0->stencil.store_action != WMTStoreActionStore)
        return false;
      if (r1->stencil.load_action != WMTLoadActionLoad)
        return false;
    }
  }
  for (unsigned i = 0; i < r0->render_target_count; i++) {
    auto &a0 = r0->colors[i];
    auto &a1 = r1->colors[i];
    if (a0.attachment != a1.attachment)
      return false;
    if (a0.depth_plane != a1.depth_plane)
      return false;
    if (!a0.attachment)
      continue;
    if (a0.store_action != WMTStoreActionStore)
      return false;
    if (a1.load_action != WMTLoadActionLoad)
      return false;
  }
  return true;
}

RenderEncoderColorAttachmentData *
ArgumentEncodingContext::isClearColorSignatureMatched(ClearEncoderData *clear, RenderEncoderData *render) {
  for (unsigned i = 0; i < render->render_target_count; i++) {
    auto &attachment = render->colors[i];
    if (attachment.attachment == clear->attachment) {
      return &attachment;
    }
  }
  return nullptr;
}

RenderEncoderDepthAttachmentData *
ArgumentEncodingContext::isClearDepthSignatureMatched(ClearEncoderData *clear, RenderEncoderData *render) {
  if ((clear->clear_dsv & 1) == 0)
    return nullptr;
  if (render->depth.attachment != clear->attachment)
    return nullptr;
  return &render->depth;
}

RenderEncoderStencilAttachmentData *
ArgumentEncodingContext::isClearStencilSignatureMatched(ClearEncoderData *clear, RenderEncoderData *render) {
  if ((clear->clear_dsv & 2) == 0)
    return nullptr;
  if (render->stencil.attachment != clear->attachment)
    return nullptr;
  return &render->stencil;
}

ArgumentEncodingContext::ResolveSignatureMatchResult
ArgumentEncodingContext::isResolveSignatureMatched(RenderEncoderData *render, ResolveEncoderData *resolve) {
  ResolveSignatureMatchResult ret{};
  for (unsigned i = 0; i < render->render_target_count; i++) {
    auto &color = render->colors[i];
    if (!color.attachment)
      continue;
    if (color.store_action != WMTStoreActionStore)
      continue;
    if (color.resolve_attachment)
      continue;
    if (color.attachment->allocation != resolve->src->allocation)
      continue;
    if (color.attachment->key == resolve->src->key) {
      ret.src = &color;
      ret.dst = resolve->dst;
      break;
    };
    auto &descriptor_src = resolve->src->allocation->descriptor;
    auto &descriptor_dst = resolve->dst->allocation->descriptor;
    auto color_format = descriptor_src->pixelFormat(color.attachment->key);
    auto view_src_in_color_format = descriptor_src->checkViewUseFormat(resolve->src->key, color_format);
    if (color.attachment->key == view_src_in_color_format) {
      auto view_dst_in_color_format = descriptor_dst->checkViewUseFormat(resolve->dst->key, color_format);
      ret.src = &color;
      ret.dst = descriptor_dst->view(view_dst_in_color_format, resolve->dst->allocation);
      break;
    }
  }
  return ret;
}

template <>
WMT::Reference<WMT::ComputePipelineState>
SimpleCommandContext<ArgumentEncodingContext>::getComputePipeline(std::string name) {
  auto lib = ctx.lib.getLibrary();
  auto func = lib.newFunction(name.c_str());
  if (!func)
    return {};
  WMT::Reference<WMT::Error> err;
  auto pso = ctx.device_.newComputePipelineState(func, err);
  if (err) {
    ERR("Failed to create compute PSO: ", err.description().getUTF8String());
  }
  return pso;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::startComputePass() {
  ctx.startComputePass(0);
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::endPass() {
  ctx.endPass();
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setComputePSO(WMT::ComputePipelineState pso, WMTSize tgsize) {
  auto &setpso = ctx.encodeComputeCommand<wmtcmd_compute_setpso>();
  setpso.type = WMTComputeCommandSetPSO;
  setpso.pso = pso;
  setpso.threadgroup_size = tgsize;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::dispatch(WMTSize size) {
  auto &dispatch = ctx.encodeComputeCommand<wmtcmd_compute_dispatch>();
  dispatch.type = WMTComputeCommandDispatchThreads;
  dispatch.size = size;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setComputeTexture(
    uint32_t index, const Rc<Texture> &texture, uint64_t viewId, int flags
) {
  auto &dst_ = ctx.access(texture, viewId, flags);
  auto &settex = ctx.encodeComputeCommand<wmtcmd_compute_settexture>();
  settex.type = WMTComputeCommandSetTexture;
  settex.texture = dst_.texture;
  settex.index = index;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setComputeTexelBuffer(
    uint32_t index, const Rc<Buffer> &buffer, uint64_t viewId, int flags
) {
  auto [dst_, dst_sub_offset] = ctx.access(buffer, viewId, flags);
  auto &settexbuf = ctx.encodeComputeCommand<wmtcmd_compute_settexture>();
  settexbuf.type = WMTComputeCommandSetTexture;
  settexbuf.texture = dst_.texture;
  settexbuf.index = index;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setComputeBuffer(
    uint32_t index, const Rc<Buffer> &buffer, uint32_t offset, uint32_t length, int flags
) {
  auto [dst_, dst_sub_offset] = ctx.access(buffer, offset, length, flags);
  auto &setbuf = ctx.encodeComputeCommand<wmtcmd_compute_setbuffer>();
  setbuf.type = WMTComputeCommandSetBuffer;
  setbuf.buffer = dst_->buffer();
  setbuf.index = index;
  setbuf.offset = 0; // the `offset` and `length` parameter of this function are just for (potential) hazard tracking,
                     // which we don't need here
}

template <>
void *
SimpleCommandContext<ArgumentEncodingContext>::setComputeBytes(uint32_t index, uint32_t length) {
  auto &setmeta = ctx.encodeComputeCommand<wmtcmd_compute_setbytes>();
  setmeta.type = WMTComputeCommandSetBytes;
  void *temp = ctx.allocate_cpu_heap(length, 16);
  setmeta.bytes.set(temp);
  setmeta.length = length;
  setmeta.index = index;
  return temp;
}

template <>
WMT::Library
SimpleCommandContext<ArgumentEncodingContext>::getDefaultLibrary() {
  return ctx.lib.getLibrary();
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::startRenderPass() {
  auto render = ctx.startRenderPass(0, 0, 0, 0);
  render->render_target_width = 16384;
  render->render_target_height = 16384;
  render->render_target_array_length = 0;
  render->default_raster_sample_count = 1;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setColorAttachment(
    uint32_t index, const Rc<Texture> &texture, uint64_t viewId, uint32_t depth_plane
) {
  auto encoder = static_cast<RenderEncoderData *>(ctx.encoder_current);

  encoder->colors[index].attachment = ctx.access<PipelineStage::Pixel>(texture, viewId, ResourceAccess::Write);
  encoder->colors[index].depth_plane = depth_plane;
  encoder->colors[index].load_action = WMTLoadActionLoad;
  encoder->colors[index].store_action = WMTStoreActionStore;
  encoder->render_target_count = std::max<uint32_t>(encoder->render_target_count, index + 1);
  encoder->render_target_width = std::min<uint32_t>(encoder->render_target_width, texture->width(viewId));
  encoder->render_target_height = std::min<uint32_t>(encoder->render_target_height, texture->height(viewId));
  encoder->render_target_array_length = texture->textureType() == WMTTextureType3D
                                            ? (texture->depth(viewId) - depth_plane)
                                            : texture->arrayLength(viewId);
  encoder->default_raster_sample_count = texture->sampleCount();
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setDepthStencilAttachment(
    const Rc<Texture> &texture, uint64_t viewId, uint32_t dsv_flag
) {
  auto encoder = static_cast<RenderEncoderData *>(ctx.encoder_current);
  if (dsv_flag & 1) {
    encoder->depth.attachment = ctx.access<PipelineStage::Pixel>(texture, viewId, ResourceAccess::Write);
    encoder->depth.load_action = WMTLoadActionLoad;
    encoder->depth.store_action = WMTStoreActionStore;
  }
  if (dsv_flag & 2) {
    encoder->stencil.attachment = ctx.access<PipelineStage::Pixel>(texture, viewId, ResourceAccess::Write);
    encoder->stencil.load_action = WMTLoadActionLoad;
    encoder->stencil.store_action = WMTStoreActionStore;
  }
  encoder->dsv_planar_flags = dsv_flag;
  encoder->render_target_width = std::min<uint32_t>(encoder->render_target_width, texture->width(viewId));
  encoder->render_target_height = std::min<uint32_t>(encoder->render_target_height, texture->height(viewId));
  encoder->render_target_array_length = texture->arrayLength(viewId);
  encoder->default_raster_sample_count = texture->sampleCount();
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setRenderPSO(WMT::RenderPipelineState pso) {
  auto &cmd = ctx.encodeRenderCommand<wmtcmd_render_setpso>();
  cmd.type = WMTRenderCommandSetPSO;
  cmd.pso = pso;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setViewport(WMTViewport viewport) {
  auto &cmd = ctx.encodeRenderCommand<wmtcmd_render_setviewport>();
  cmd.type = WMTRenderCommandSetViewport;
  cmd.viewport = viewport;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setDepthStencilState(WMT::DepthStencilState dsso) {
  auto &cmd = ctx.encodeRenderCommand<wmtcmd_render_setdepthstencilstate>();
  cmd.type = WMTRenderCommandSetDepthStencilState;
  cmd.depth_stencil_state = dsso;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setScissorRect(WMTScissorRect rect) {
  auto &cmd = ctx.encodeRenderCommand<wmtcmd_render_setscissorrect>();
  cmd.type = WMTRenderCommandSetScissorRect;
  cmd.scissor_rect = rect;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::setStencilReference(uint8_t stencil_ref) {
  auto &cmd = ctx.encodeRenderCommand<wmtcmd_render_setstencilref>();
  cmd.type = WMTRenderCommandSetStencilRef;
  cmd.stencil_ref = stencil_ref;
}

template <>
void *
SimpleCommandContext<ArgumentEncodingContext>::setFragmentBytes(uint32_t index, uint32_t length) {
  auto &setmeta = ctx.encodeRenderCommand<wmtcmd_render_setbytes>();
  setmeta.type = WMTRenderCommandSetFragmentBytes;
  void *temp = ctx.allocate_cpu_heap(length, 16);
  setmeta.bytes.set(temp);
  setmeta.length = length;
  setmeta.index = index;
  return temp;
}

template <>
void
SimpleCommandContext<ArgumentEncodingContext>::draw(
    WMTPrimitiveType primitive, uint32_t vertex_start, uint32_t vertex_count, int32_t base_instance,
    uint32_t instance_count
) {
  auto &draw = ctx.encodeRenderCommand<wmtcmd_render_draw>();
  draw.type = WMTRenderCommandDraw;
  draw.primitive_type = primitive;
  draw.vertex_start = vertex_start;
  draw.vertex_count = vertex_count;
  draw.base_instance = base_instance;
  draw.instance_count = instance_count;
}

} // namespace dxmt